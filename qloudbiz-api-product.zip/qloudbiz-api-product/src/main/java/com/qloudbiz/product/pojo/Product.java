package com.qloudbiz.product.pojo;

import lombok.Data;

@Data
public class Product {
	private String productId;
	private String code;
	private String name;
}
