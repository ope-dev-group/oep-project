package com.qloudbiz.product.service;


public interface ProductServiceInterface {
	
	public void save();

	
	public void update() ;
	
	public void query();

}
